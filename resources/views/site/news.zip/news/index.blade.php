

<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12 marginTopBottom">
   <ul class="opollo">
   @foreach ($results as $result)
  
                    <li>
                        <div class="title">{{$result->news_title}}</h3>
  		 </div>
                        <div class="content">
                            <div class="thumbnail text-center">
						<a href="news-updates-details.html">
							{!! HTML::image("$imagesPath"."thumbnail-"."$result->image_filename","alt") !!}
  		
						</a>
					</div>
                            <div class="datestamped">
                                <div class="day">{!! date('d',strtotime($result->news_date)) !!}</div>
                                <div class="monthYear">{!! date('M',strtotime($result->news_date)) !!}<br />{!! date('Y',strtotime($result->news_date)) !!}</div>
                            </div>
                            <div class="description">{!! $result->description !!}
</div>
                        </div>
                        <div class="readMore">
                            {!! HTML::linkAction('Site\NewsController@preview',  "read more", array($slug,$result->slug),array('class'=>'more')) !!}
                        </div>
                    </li>
         @endforeach           
         </ul>
         <div class="clearfix"></div>
         </div>