<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                <h2 class="marginBottom">Archive</h2>
                <div class="sidemenu">

<ul>
@foreach ($archive as $key=>$value)
        			<li>
        				<a href="#">{{ $key }}</a>
        				<ul>
        				@foreach ($value as $keyMonth =>$valueMonth)
        					<li>
        						<a href="#">{{ $keyMonth }}</a>
        						<ul>
        						@foreach ($valueMonth as $news)
  									<li>{!! HTML::linkAction('Site\NewsController@preview',  $news->news_title , array($slug,$news->slug)) !!}</li>
  								@endforeach
        							</ul>
        							</li>
        							@endforeach
        					</ul>
        				</li>
        				@endforeach
        			</ul>
        			</div>
        		<div class="clearfix"></div>
                </div>